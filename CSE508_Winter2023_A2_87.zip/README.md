# CSE508_Winter2023_A2_87

For all 3 sections to recreate the results simply clone this repository and run the notebooks present in the different directories.